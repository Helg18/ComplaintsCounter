var classcomplaints =
[
    [ "DeleteComplaint", "classcomplaints.html#aeb865ac04e7eaaaa175b280cf05eb620", null ],
    [ "DeleteUploadFile", "classcomplaints.html#aaf9b6ba576c8ad4969082fd9c312478a", null ],
    [ "ExplorerReviews", "classcomplaints.html#a94a40692d70b38155d07dac2cbfa16e0", null ],
    [ "GetComplaintById", "classcomplaints.html#ade5f93cfa810e361a8bad72eb7ede4b3", null ],
    [ "GetResponseByComplaintid", "classcomplaints.html#a5337815d4b803e44348fcd1bafe68066", null ],
    [ "InsertResponse", "classcomplaints.html#ac5a816395208854569adbfc632b3c010", null ],
    [ "loadcomplaintsforbusiness", "classcomplaints.html#a59e83d0a296180cc04709bd3d09a175e", null ],
    [ "loadcomplaintsforusers", "classcomplaints.html#abe3f97e69e594b55f4fc26aced0365af", null ],
    [ "SendEmailContactUs", "classcomplaints.html#a31338181cf039db4b5b90df7ba9f9d47", null ],
    [ "SendLetter", "classcomplaints.html#ad2d777561e79d06236f519be1c064eff", null ],
    [ "ShowMoreComplaints", "classcomplaints.html#a80f4ba4e535db15fd19ae4106fe0429b", null ],
    [ "ShowPreviewComplaint", "classcomplaints.html#a3dccf894cf5f745048a0d128a42aa457", null ],
    [ "ShowSendLetter", "classcomplaints.html#a65a52d79e80810a967b69c740774fc2f", null ],
    [ "UpdateActionComplaint", "classcomplaints.html#a5aee24f611011e0683725fcf99a6e6c6", null ],
    [ "uploadFileResponse", "classcomplaints.html#a80311f2aa12153c006590d1868de6b63", null ]
];