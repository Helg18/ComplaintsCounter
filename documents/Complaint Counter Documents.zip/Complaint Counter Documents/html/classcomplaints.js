var classcomplaints =
[
    [ "DeleteComplaint", "classcomplaints.html#aeb865ac04e7eaaaa175b280cf05eb620", null ],
    [ "ExplorerReviews", "classcomplaints.html#a94a40692d70b38155d07dac2cbfa16e0", null ],
    [ "GetResponseByComplaintid", "classcomplaints.html#a5337815d4b803e44348fcd1bafe68066", null ],
    [ "loadcomplaintsforbusiness", "classcomplaints.html#a2f6153dd4f5684904735d6d487757338", null ],
    [ "ShowMoreComplaints", "classcomplaints.html#afab04e1ec834e6005cea65e867511f60", null ],
    [ "ShowPreviewComplaint", "classcomplaints.html#a3dccf894cf5f745048a0d128a42aa457", null ],
    [ "UpdateActionComplaint", "classcomplaints.html#a5aee24f611011e0683725fcf99a6e6c6", null ]
];