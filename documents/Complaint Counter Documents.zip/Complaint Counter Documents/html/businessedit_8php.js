var businessedit_8php =
[
    [ "$user", "businessedit_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ],
    [ "if", "businessedit_8php.html#af28e8a4edeaca90c16576d17fe48cf88", null ]
];