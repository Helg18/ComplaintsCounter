var dir_1cdd598f34e89a30f85c43cbc873c1df =
[
    [ "EasyCry.php", "_easy_cry_8php.html", [
      [ "EasyCry", "class_easy_cry.html", "class_easy_cry" ]
    ] ],
    [ "geoplugin.class.php", "geoplugin_8class_8php.html", [
      [ "geoPlugin", "classgeo_plugin.html", "classgeo_plugin" ]
    ] ],
    [ "ip2locationlite.class.php", "ip2locationlite_8class_8php.html", [
      [ "ip2location_lite", "classip2location__lite.html", "classip2location__lite" ]
    ] ]
];