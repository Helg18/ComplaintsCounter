var searchData=
[
  ['db',['DB',['../db_8php.html#a002c9e0914e76f1d582bcd6a51299ea2',1,'db.php']]],
  ['docel',['docEl',['../index_8php.html#a2f3a805950efa4087f2052e684d56f76',1,'index.php']]]
];
