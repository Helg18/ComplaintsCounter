var searchData=
[
  ['db',['DB',['../db_8php.html#a002c9e0914e76f1d582bcd6a51299ea2',1,'db.php']]],
  ['docel',['docEl',['../index_8php.html#adddca3114d38fe93fb71545a54b8fed0',1,'index.php']]]
];
