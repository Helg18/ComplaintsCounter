var searchData=
[
  ['loadcomplaintsforbusiness',['loadcomplaintsforbusiness',['../classcomplaints.html#a59e83d0a296180cc04709bd3d09a175e',1,'complaints']]],
  ['loadcomplaintsforusers',['loadcomplaintsforusers',['../classcomplaints.html#abe3f97e69e594b55f4fc26aced0365af',1,'complaints']]],
  ['loadregisterpage',['loadRegisterPage',['../functions_8js.html#af430c789044269cc5d476e429faead2c',1,'functions.js']]],
  ['locate',['locate',['../classgeo_plugin.html#aff9d1e3a4ce928c057f8a5611be689da',1,'geoPlugin']]],
  ['locateip',['LocateIp',['../functions_8php.html#ab5c09e13d03b1a33609d3177e2919d93',1,'functions.php']]],
  ['logout',['Logout',['../functions_8php.html#aa14f760d541a59acb41ac8eefddafb9b',1,'functions.php']]],
  ['ltrim',['ltrim',['../functions_8js.html#aabf8f25a0947f0115a17109c1f5a7f89',1,'functions.js']]]
];
