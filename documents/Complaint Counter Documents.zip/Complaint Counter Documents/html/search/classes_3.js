var searchData=
[
  ['geoplugin',['geoPlugin',['../classgeo_plugin.html',1,'']]]
];
