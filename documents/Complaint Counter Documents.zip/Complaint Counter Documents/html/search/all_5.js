var searchData=
[
  ['db',['DB',['../db_8php.html#a002c9e0914e76f1d582bcd6a51299ea2',1,'db.php']]],
  ['db_2ephp',['db.php',['../db_8php.html',1,'']]],
  ['decode',['decode',['../class_easy_cry.html#a02eeca1d3d2115cc3661c1502a8f86cf',1,'EasyCry']]],
  ['decrypt_2ephp',['decrypt.php',['../decrypt_8php.html',1,'']]],
  ['deletebusiness',['deleteBusiness',['../functions_8js.html#aafad38705911fff04721c8e9d210101a',1,'functions.js']]],
  ['deletecomplaint',['DeleteComplaint',['../classcomplaints.html#aeb865ac04e7eaaaa175b280cf05eb620',1,'complaints\DeleteComplaint()'],['../functions_8js.html#a1219280ec16aac377082b0db70528829',1,'deleteComplaint():&#160;functions.js']]],
  ['deleteneworganisation',['DeleteNewOrganisation',['../classsubscription.html#a8c9b82e13025fcca75cb1f30571f5043',1,'subscription']]],
  ['deleteorganisation',['DeleteOrganisation',['../classsubscription.html#aa6b83dc47b822d755a8d7dfeefcec158',1,'subscription\DeleteOrganisation()'],['../functions_8js.html#a9d02e840228bfbe557f5c3fc16a60c32',1,'deleteOrganisation():&#160;functions.js']]],
  ['deleteuploadfile',['DeleteUploadFile',['../classcomplaints.html#aaf9b6ba576c8ad4969082fd9c312478a',1,'complaints']]],
  ['deleteuser',['DeleteUser',['../classsubscription.html#a78184e4b0d987dd4069cbb68628a56dc',1,'subscription\DeleteUser()'],['../functions_8js.html#aa7066876455285cc289ec9814bbb2bf8',1,'deleteUser():&#160;functions.js']]],
  ['disablekeys',['disableKeys',['../functions_8js.html#affbca7ed66bf939886b512d452c8f05e',1,'functions.js']]],
  ['docel',['docEl',['../index_8php.html#a2f3a805950efa4087f2052e684d56f76',1,'index.php']]],
  ['dologin',['DoLogin',['../functions_8php.html#a6952321c98ee52b3a0d0d34e91c22d6a',1,'functions.php']]]
];
