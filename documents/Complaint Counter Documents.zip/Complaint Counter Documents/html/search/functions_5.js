var searchData=
[
  ['insertsubscription',['InsertSubscription',['../classsubscription.html#aebf6cfd195ecc7d00dc77e8183de447f',1,'subscription']]],
  ['insertuser',['InsertUser',['../classsubscription.html#ad971f82fe5777312761ffbf341fd32b8',1,'subscription']]]
];
