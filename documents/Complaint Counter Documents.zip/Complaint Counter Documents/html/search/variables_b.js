var searchData=
[
  ['user',['USER',['../db_8php.html#a1bbff5b87a1e3a8d402d50c9fdb4e6e9',1,'db.php']]]
];
