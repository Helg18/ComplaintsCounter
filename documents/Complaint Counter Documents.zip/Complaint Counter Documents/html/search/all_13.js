var searchData=
[
  ['well',['well',['../index_8php.html#a5781a63f4a3995dd7d7caab6666b567b',1,'index.php']]],
  ['win',['win',['../index_8php.html#aa9a0a8f5f88eaabaa4d19117003d7a3c',1,'index.php']]]
];
