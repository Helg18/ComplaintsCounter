var searchData=
[
  ['refuse',['refuse',['../index_8php.html#ae20ae72bc3ca2a4541888f6108045161',1,'index.php']]],
  ['right',['right',['../index_8php.html#ab9c1d82fa8fe9cf30e02e3dbf15c3551',1,'index.php']]]
];
