var indexSectionsWithContent =
{
  0: "$_abcdefghilmnoprstuvw",
  1: "bcegips",
  2: "abcdefghilmprstu",
  3: "_abcdefgilmnoprstuv",
  4: "$abcdefhinoprsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

