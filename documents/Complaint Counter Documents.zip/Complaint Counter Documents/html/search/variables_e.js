var searchData=
[
  ['upload_5fdir',['UPLOAD_DIR',['../db_8php.html#a268495a816754fb38b7dd0c1ab7c56fa',1,'db.php']]],
  ['user',['USER',['../db_8php.html#a1bbff5b87a1e3a8d402d50c9fdb4e6e9',1,'db.php']]]
];
