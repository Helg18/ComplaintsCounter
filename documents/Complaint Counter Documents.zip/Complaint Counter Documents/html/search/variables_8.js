var searchData=
[
  ['if',['if',['../businessedit_8php.html#af28e8a4edeaca90c16576d17fe48cf88',1,'if():&#160;businessedit.php'],['../recoverpass_8php.html#a920c03dfbe3000bd39150db34d4d38b7',1,'if():&#160;recoverpass.php'],['../useredit_8php.html#a0778f4abe1113f63b548d4b959c1df64',1,'if():&#160;useredit.php'],['../userlog_8php.html#a08d9d3ba795024d7d4a9ec45e3f9140a',1,'if():&#160;userlog.php']]]
];
