var searchData=
[
  ['geoplugin_2eclass_2ephp',['geoplugin.class.php',['../geoplugin_8class_8php.html',1,'']]]
];
