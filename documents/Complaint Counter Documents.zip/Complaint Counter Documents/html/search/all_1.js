var searchData=
[
  ['_5f_5fconstruct',['__construct',['../classip2location__lite.html#a095c5d389db211932136b53f25f39685',1,'ip2location_lite']]],
  ['_5f_5fdestruct',['__destruct',['../classip2location__lite.html#a421831a265621325e1fdd19aace0c758',1,'ip2location_lite']]]
];
