var searchData=
[
  ['validatephone',['validatephone',['../functions_8js.html#a562468ec2e42ca14f21426f10926daeb',1,'functions.js']]],
  ['validatepostcode',['validatepostcode',['../functions_8js.html#ac69b8112f0a039f4261a9f4eb0b27e93',1,'functions.js']]],
  ['validemail',['validEmail',['../functions_8js.html#a369c144db1ec7a58b7f18f1cc5d989d2',1,'functions.js']]],
  ['validurl',['validUrl',['../functions_8js.html#a29590b1e015aea6ea7afb615c1a4627f',1,'functions.js']]]
];
