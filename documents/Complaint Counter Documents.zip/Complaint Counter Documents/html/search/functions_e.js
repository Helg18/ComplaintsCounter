var searchData=
[
  ['recoverpassword',['RecoverPassword',['../classsubscription.html#a6c286a9e0225dfd565e1a19641bc0b1f',1,'subscription\RecoverPassword()'],['../functions_8js.html#ad5b284165f7924b48b7ed3d5d9a2ca22',1,'RecoverPassword():&#160;functions.js']]],
  ['registerbusiness',['registerBusiness',['../functions_8js.html#adcc258288aa6070735118cfb0938bce8',1,'functions.js']]],
  ['rejectbusiness',['RejectBusiness',['../classsubscription.html#ad6a591b6f7cd87bb161a2d1609ddcfa5',1,'subscription\RejectBusiness()'],['../functions_8js.html#a77389c8af8085b9a366159edb51b8b48',1,'rejectBusiness():&#160;functions.js']]],
  ['removeerrormessage',['removeErrorMessage',['../functions_8js.html#a78e71a833b24946b69f74a426593c708',1,'functions.js']]],
  ['removeerrormessageonclick',['removeErrorMessageOnClick',['../functions_8js.html#a973d4e2e095692932a445c1c4032fd91',1,'functions.js']]],
  ['resetpassword',['ResetPassword',['../functions_8js.html#a00bac3f70375545aa8c04a647c5a6132',1,'functions.js']]],
  ['resetpasswordedituser',['ResetPasswordEditUser',['../functions_8js.html#a55ebc2615bf9f34482ccf526e97554af',1,'functions.js']]],
  ['responsecomplaint',['responseComplaint',['../functions_8js.html#a92e895f8c8ed1dcb9d541e5d91755cf9',1,'functions.js']]],
  ['reviewtext',['reviewText',['../functions_8js.html#a1a1f56e3583a3dfeb461a14735dec03f',1,'functions.js']]],
  ['rtrim',['rtrim',['../functions_8js.html#ab924ac9c898c2de83d8457a10d2487e9',1,'functions.js']]]
];
