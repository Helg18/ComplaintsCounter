var searchData=
[
  ['complaints',['complaints',['../classcomplaints.html',1,'']]]
];
