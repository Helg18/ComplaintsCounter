var searchData=
[
  ['loadcomplaintsforbusiness',['loadcomplaintsforbusiness',['../classcomplaints.html#a2f6153dd4f5684904735d6d487757338',1,'complaints']]],
  ['logout',['Logout',['../functions_8php.html#aa14f760d541a59acb41ac8eefddafb9b',1,'functions.php']]]
];
