var searchData=
[
  ['deletecomplaint',['DeleteComplaint',['../classcomplaints.html#aeb865ac04e7eaaaa175b280cf05eb620',1,'complaints']]],
  ['dologin',['DoLogin',['../functions_8php.html#a6952321c98ee52b3a0d0d34e91c22d6a',1,'functions.php']]]
];
