var searchData=
[
  ['blockuser',['BlockUser',['../classsubscription.html#a518f5b92f3280e3376303b63ce48d94d',1,'subscription\BlockUser()'],['../functions_8js.html#a6ab008e9454c6109c632833076b11b1e',1,'blockUser():&#160;functions.js']]],
  ['broadcast24',['broadcast24',['../classbroadcast.html#ab36857561598fba124e5160e060b68e0',1,'broadcast']]],
  ['broadcastcomplaint',['BroadcastComplaint',['../classbroadcast.html#a951596f9e03a855e7f3a1bdd0bfffcb3',1,'broadcast\BroadcastComplaint()'],['../functions_8js.html#a0abe66de4f77302d653b4725b3c20d29',1,'broadcastComplaint():&#160;functions.js']]],
  ['broadcastcomplaintuser',['BroadcastComplaintUser',['../classbroadcast.html#a63758fd2eec8397498c3734251078e45',1,'broadcast\BroadcastComplaintUser()'],['../functions_8js.html#a6e91fac6074a4abed49726e8b5cbcc62',1,'broadcastComplaintUser():&#160;functions.js']]],
  ['businesslist',['businessList',['../functions_8js.html#a7ef236f3b0a8c826428e73c62286f585',1,'functions.js']]]
];
