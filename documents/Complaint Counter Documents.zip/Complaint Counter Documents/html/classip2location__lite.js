var classip2location__lite =
[
    [ "__construct", "classip2location__lite.html#a095c5d389db211932136b53f25f39685", null ],
    [ "__destruct", "classip2location__lite.html#a421831a265621325e1fdd19aace0c758", null ],
    [ "getCity", "classip2location__lite.html#a40dd0f01cd5cbdb134eeb86021375ed7", null ],
    [ "getCountry", "classip2location__lite.html#a86702f3120724183d03df96ae1a2b550", null ],
    [ "getError", "classip2location__lite.html#a24ada5decce3d1b79cd82f5a90ccf404", null ],
    [ "setKey", "classip2location__lite.html#a9afc10d017d5c65d3e6a941f65cf1904", null ],
    [ "$apiKey", "classip2location__lite.html#a084e3db37d1b117a3cc7212cf2eed533", null ],
    [ "$errors", "classip2location__lite.html#ab24faf4aa647cdcee494fc48524ad4ff", null ],
    [ "$service", "classip2location__lite.html#abb8d1943d2cf9b6a3d54a4fed1ad2d9d", null ],
    [ "$version", "classip2location__lite.html#a17c8948c68aa44fa9961ae169b6a8961", null ]
];