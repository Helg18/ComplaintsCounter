var classgeo_plugin =
[
    [ "convert", "classgeo_plugin.html#a32cb2cb271eee2f4060fc2b32056ef77", null ],
    [ "fetch", "classgeo_plugin.html#ad01381518de0f2ffe6ba19b1486ea5c4", null ],
    [ "geoPlugin", "classgeo_plugin.html#a2da4a935a15c3fc0d7f0f0c5ef42425e", null ],
    [ "locate", "classgeo_plugin.html#aff9d1e3a4ce928c057f8a5611be689da", null ],
    [ "nearby", "classgeo_plugin.html#a1ee9c7c734e535c97990c5756487cce2", null ],
    [ "$areaCode", "classgeo_plugin.html#a51a96be9b3812c0d2ad65c8322c96ced", null ],
    [ "$city", "classgeo_plugin.html#a5b9ddd3e3a69d8901270064346bdef49", null ],
    [ "$continentCode", "classgeo_plugin.html#a981120f485cf7433cb04fa3ca154d08a", null ],
    [ "$countryCode", "classgeo_plugin.html#abdcb2737ce393c29ee3a480f2cc1ab0f", null ],
    [ "$countryName", "classgeo_plugin.html#a1570d84454fa6062e53775e15832406a", null ],
    [ "$currency", "classgeo_plugin.html#a37d22fd3b896e9d5488f3479a4d8f451", null ],
    [ "$currencyCode", "classgeo_plugin.html#aa7bd6d84d1b97dd03f1e6e03ea1dc589", null ],
    [ "$currencyConverter", "classgeo_plugin.html#a6155266d2da2d885b13001b2118730b1", null ],
    [ "$currencySymbol", "classgeo_plugin.html#a7fff6ab644556d314ce5d614bd2bba77", null ],
    [ "$dmaCode", "classgeo_plugin.html#aca47cf8acf97d596e959f12aa4e0f19c", null ],
    [ "$host", "classgeo_plugin.html#a711797613cb863ca0756df789c396bf2", null ],
    [ "$ip", "classgeo_plugin.html#a9a08c84edd46f257c94cdf8d443cc77d", null ],
    [ "$latitude", "classgeo_plugin.html#a5635a7326fb0b96e184ca6f5baa13e94", null ],
    [ "$longitude", "classgeo_plugin.html#aabb5b5c018fed3789fce382e336cfa47", null ],
    [ "$region", "classgeo_plugin.html#a8e0b4669db3780ee9a03b34083febc7a", null ]
];