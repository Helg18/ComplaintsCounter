var fun__jq_8php =
[
    [ "CreateUser", "fun__jq_8php.html#afbf9833bb9da3133de2794c222eb7548", null ],
    [ "$conn", "fun__jq_8php.html#aa8a5a87b9c1a6a0819b88447cbe41877", null ]
];