var annotated_dup =
[
    [ "broadcast", "classbroadcast.html", "classbroadcast" ],
    [ "complaints", "classcomplaints.html", "classcomplaints" ],
    [ "subscription", "classsubscription.html", "classsubscription" ]
];