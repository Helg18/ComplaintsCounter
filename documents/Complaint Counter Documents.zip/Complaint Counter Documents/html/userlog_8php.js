var userlog_8php =
[
    [ "$lastcomplaintid", "userlog_8php.html#a92fa7638cd7e86d7a7e6bfbb5aa1a9c0", null ],
    [ "$user", "userlog_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ],
    [ "$userid", "userlog_8php.html#af17beb34c758b7ee45f6ecaf74cf0540", null ],
    [ "$username", "userlog_8php.html#a0eb82aa5f81cf845de4b36cd653c42cf", null ]
];