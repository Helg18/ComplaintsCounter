var classsubscription =
[
    [ "CheckLogin", "classsubscription.html#a78789f5141a523d7319e5bc712692374", null ],
    [ "CheckSubscriptionEmail", "classsubscription.html#adada031811864d13baee1da2ee81ee25", null ],
    [ "CheckSubscriptionEmailChange", "classsubscription.html#adfb7a80ee6721f2ca9feb7783fdd910e", null ],
    [ "CreateBillingAgreement", "classsubscription.html#a7252fa03d11a2f742753e72adf60d19b", null ],
    [ "CreateBillingPlan", "classsubscription.html#aacab7be6a3ee80222286f328646b524e", null ],
    [ "EmailForgotPassword", "classsubscription.html#ab7d63372160c5031c1434e18e1b72d54", null ],
    [ "GetSubcription", "classsubscription.html#a6ae0c7347a48dba977379f76b55f4dd2", null ],
    [ "GetUser", "classsubscription.html#aa3cc90d209861fdb8c5903fb0d6ff3d5", null ],
    [ "InsertSubscription", "classsubscription.html#aebf6cfd195ecc7d00dc77e8183de447f", null ],
    [ "InsertUser", "classsubscription.html#ad971f82fe5777312761ffbf341fd32b8", null ],
    [ "RecoverPassword", "classsubscription.html#a6c286a9e0225dfd565e1a19641bc0b1f", null ],
    [ "SendSubscriptionEmail", "classsubscription.html#a5e1702aa8eed5442d9551681400f95bb", null ],
    [ "UpdateBillingPlan", "classsubscription.html#ad10749c0e2d74c516bc0bcc96165d07a", null ],
    [ "updateSubscription", "classsubscription.html#a2cae0ce8ca9354d179a79e3376801c8b", null ],
    [ "UpdateUser", "classsubscription.html#ae232e9c8271ed06ea3d0874933788a0b", null ],
    [ "$agreementid", "classsubscription.html#abb9f0bb33bcf9a7872cca51876e4328c", null ]
];