var header_8php =
[
    [ "$dashboard", "header_8php.html#a056461fb25fc07d8dc5fd1bae85f1e37", null ],
    [ "$menuloginhidden", "header_8php.html#a50cf8e17210a09985dcdf156ac7a4eb5", null ],
    [ "$nameuser", "header_8php.html#ad568c110e689d5b9edda60b65580d97e", null ],
    [ "$remember_me", "header_8php.html#a536e31ab2e9e51a92dc2c4597d3d9246", null ],
    [ "$rememberpass", "header_8php.html#ae585b26d29f9fe3b43106a07e5ece445", null ],
    [ "$user", "header_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ],
    [ "$useremail", "header_8php.html#abe2f181ad89ba732679712349261287a", null ],
    [ "false", "header_8php.html#a5df37b7f02e5cdc7d9412b7f872b8e01", null ],
    [ "name", "header_8php.html#ab74e6bf80237ddc4109968cedc58c151", null ]
];