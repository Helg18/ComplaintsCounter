var functions_8php =
[
    [ "DoLogin", "functions_8php.html#a6952321c98ee52b3a0d0d34e91c22d6a", null ],
    [ "generateRandomString", "functions_8php.html#af2deeb79b5c0825d05721daa2c272044", null ],
    [ "getBaseUrl", "functions_8php.html#ae1ca0d2444e3cca6b147445348f686de", null ],
    [ "GetGeolocation", "functions_8php.html#ab48d1a12cffbf14bdb7636aa33386797", null ],
    [ "GetPlanName", "functions_8php.html#ade9f1fc3871d6ef501c742aaa4b04aea", null ],
    [ "GetUserSession", "functions_8php.html#a0353354aa1b3a0a853b31f296cfc2d5f", null ],
    [ "LocateIp", "functions_8php.html#ab5c09e13d03b1a33609d3177e2919d93", null ],
    [ "Logout", "functions_8php.html#aa14f760d541a59acb41ac8eefddafb9b", null ],
    [ "mail_attachment", "functions_8php.html#ab6d1aa48fb15209a24569f7b2a511557", null ],
    [ "SendEmail", "functions_8php.html#a99173c3141a3519644f41b8f7729f1ae", null ],
    [ "SendEmailContactUs", "functions_8php.html#a31338181cf039db4b5b90df7ba9f9d47", null ],
    [ "trim_text", "functions_8php.html#aead5e168935bdb00c1173f229bb640ca", null ],
    [ "url_exists", "functions_8php.html#a79a894b8fefaa6721bbcc19f83fb2525", null ]
];