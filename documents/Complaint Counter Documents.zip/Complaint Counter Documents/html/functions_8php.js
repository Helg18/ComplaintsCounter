var functions_8php =
[
    [ "DoLogin", "functions_8php.html#a6952321c98ee52b3a0d0d34e91c22d6a", null ],
    [ "generateRandomString", "functions_8php.html#af2deeb79b5c0825d05721daa2c272044", null ],
    [ "GetUserSession", "functions_8php.html#a0353354aa1b3a0a853b31f296cfc2d5f", null ],
    [ "Logout", "functions_8php.html#aa14f760d541a59acb41ac8eefddafb9b", null ],
    [ "SendEmail", "functions_8php.html#a99173c3141a3519644f41b8f7729f1ae", null ],
    [ "trim_text", "functions_8php.html#aead5e168935bdb00c1173f229bb640ca", null ],
    [ "url_exists", "functions_8php.html#a79a894b8fefaa6721bbcc19f83fb2525", null ]
];