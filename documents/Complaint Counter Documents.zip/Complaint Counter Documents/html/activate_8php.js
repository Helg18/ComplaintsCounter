var activate_8php =
[
    [ "$token", "activate_8php.html#a00ae4fcafb1145f5e968bdf920f83e2e", null ],
    [ "$user", "activate_8php.html#a598ca4e71b15a1313ec95f0df1027ca5", null ],
    [ "else", "activate_8php.html#a6f583d5341ed94b3752afaecdd2a828a", null ]
];