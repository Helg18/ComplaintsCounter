var explore_8php =
[
    [ "$logged", "explore_8php.html#a4dd3d70333519dc20188fc463c6da3af", null ],
    [ "$searchbusinessbyid", "explore_8php.html#adf35d6ba8f4f1e8cf3ff54a470b2f10b", null ],
    [ "$title", "explore_8php.html#ada57e7bb7c152edad18fe2f166188691", null ],
    [ "$userid", "explore_8php.html#ae3f4f74a2aff9863a4767269a47aea11", null ],
    [ "else", "explore_8php.html#a5cd5dbe32e28c0199ef29727b5ea6711", null ]
];