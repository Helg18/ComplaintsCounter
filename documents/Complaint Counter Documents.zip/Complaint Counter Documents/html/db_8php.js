var db_8php =
[
    [ "phpmkr_db_close", "db_8php.html#a0a6e5060218009b307a386faac6ef0fe", null ],
    [ "phpmkr_db_connect", "db_8php.html#a3da338b6b9549e75450929a9b9e238c6", null ],
    [ "phpmkr_error", "db_8php.html#ad266d3a35041f2ff96b261c0c933d7db", null ],
    [ "phpmkr_fetch_array", "db_8php.html#ab0c79e53da153ee11f3dd7aea4ef596b", null ],
    [ "phpmkr_fetch_row", "db_8php.html#a9ec8d93b07626fd33e4c31cd92974c97", null ],
    [ "phpmkr_num_rows", "db_8php.html#ad74ebeeae4014fa038b3d1b4f61e0f4c", null ],
    [ "phpmkr_query", "db_8php.html#a0513d2e4227ec741ac9bd63598b05333", null ],
    [ "BROADCASTEMAIL", "db_8php.html#a510227790c43f32242e7c01a24cda324", null ],
    [ "DB", "db_8php.html#a002c9e0914e76f1d582bcd6a51299ea2", null ],
    [ "EMAIL", "db_8php.html#a012cde27958c21fff18f42b21dd26408", null ],
    [ "HOST", "db_8php.html#a6768772c01f2d4f111fabd25012e8259", null ],
    [ "PASS", "db_8php.html#a721e0e48b7536b275be96f3018324f28", null ],
    [ "PORT", "db_8php.html#ab9a2d2c70deaf0f75cf0ee531f6ed0b5", null ],
    [ "USER", "db_8php.html#a1bbff5b87a1e3a8d402d50c9fdb4e6e9", null ]
];