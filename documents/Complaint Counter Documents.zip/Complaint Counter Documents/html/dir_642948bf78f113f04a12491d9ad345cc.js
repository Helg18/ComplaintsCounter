var dir_642948bf78f113f04a12491d9ad345cc =
[
    [ "cron", "dir_c36613b677f773ee6b77d5eafc9140c0.html", "dir_c36613b677f773ee6b77d5eafc9140c0" ],
    [ "js", "dir_8d9b2845d359398275145c57d8cbdac7.html", "dir_8d9b2845d359398275145c57d8cbdac7" ],
    [ "lib", "dir_1cdd598f34e89a30f85c43cbc873c1df.html", "dir_1cdd598f34e89a30f85c43cbc873c1df" ],
    [ "activate.php", "activate_8php.html", "activate_8php" ],
    [ "businessedit.php", "businessedit_8php.html", "businessedit_8php" ],
    [ "complaints.php", "complaints_8php.html", [
      [ "complaints", "classcomplaints.html", "classcomplaints" ]
    ] ],
    [ "contact.php", "contact_8php.html", "contact_8php" ],
    [ "db.php", "db_8php.html", "db_8php" ],
    [ "decrypt.php", "decrypt_8php.html", "decrypt_8php" ],
    [ "explore.php", "explore_8php.html", "explore_8php" ],
    [ "footer.php", "footer_8php.html", null ],
    [ "fun_jq.php", "fun__jq_8php.html", "fun__jq_8php" ],
    [ "functions.php", "functions_8php.html", "functions_8php" ],
    [ "header.php", "header_8php.html", "header_8php" ],
    [ "howitworks.php", "howitworks_8php.html", "howitworks_8php" ],
    [ "index.php", "index_8php.html", "index_8php" ],
    [ "logout.php", "logout_8php.html", null ],
    [ "modalmessages.php", "modalmessages_8php.html", null ],
    [ "payments.php", "payments_8php.html", [
      [ "payments", "classpayments.html", "classpayments" ]
    ] ],
    [ "preview.php", "preview_8php.html", null ],
    [ "previewpayment.php", "previewpayment_8php.html", null ],
    [ "recoverpass.php", "recoverpass_8php.html", "recoverpass_8php" ],
    [ "register.php", "register_8php.html", "register_8php" ],
    [ "register_cancel.php", "register__cancel_8php.html", "register__cancel_8php" ],
    [ "register_success.php", "register__success_8php.html", "register__success_8php" ],
    [ "reset.php", "reset_8php.html", "reset_8php" ],
    [ "reset_success.php", "reset__success_8php.html", "reset__success_8php" ],
    [ "response.php", "response_8php.html", null ],
    [ "sendletter.php", "sendletter_8php.html", null ],
    [ "subscription.php", "subscription_8php.html", [
      [ "subscription", "classsubscription.html", "classsubscription" ]
    ] ],
    [ "subscriptionaccount.php", "subscriptionaccount_8php.html", "subscriptionaccount_8php" ],
    [ "termsofuse.php", "termsofuse_8php.html", "termsofuse_8php" ],
    [ "useraccount.php", "useraccount_8php.html", "useraccount_8php" ],
    [ "useredit.php", "useredit_8php.html", "useredit_8php" ],
    [ "userlog.php", "userlog_8php.html", "userlog_8php" ]
];